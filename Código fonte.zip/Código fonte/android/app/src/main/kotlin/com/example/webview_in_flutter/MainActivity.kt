package com.example.webview_in_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
